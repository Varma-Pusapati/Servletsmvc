function addtocart1() {
  const element = document.getElementById("1").value;

  var my = sessionStorage.getItem(element);
  var itemQuantity = Number(my);
  console.log(itemQuantity);
  if (element == null) {
    itemQuantity = 0;
  } else {
    itemQuantity += 1;
  }

  alert("ORDER PLACED FOR : " + element + "\n" + "QUANTITY : " + itemQuantity);

  sessionStorage.setItem(element, itemQuantity);

  let data = sessionStorage.getItem(element);
  cartcount();
}

function addtocart2() {
  const element = document.getElementById("2").value;

  var my = sessionStorage.getItem(element);
  var itemQuantity = Number(my);
  console.log(itemQuantity);
  if (element == null) {
    itemQuantity = 0;
  } else {
    itemQuantity += 1;
  }

  alert("ORDER PLACED FOR : " + element + "\n" + "QUANTITY : " + itemQuantity);

  sessionStorage.setItem(element, itemQuantity);

  let data = sessionStorage.getItem(element);
  cartcount();
}
function addtocart3() {
  const element = document.getElementById("3").value;

  var my = sessionStorage.getItem(element);
  var itemQuantity = Number(my);
  console.log(itemQuantity);
  if (element == null) {
    itemQuantity = 0;
  } else {
    itemQuantity += 1;
  }

  alert("ORDER PLACED FOR : " + element + "\n" + "QUANTITY : " + itemQuantity);

  sessionStorage.setItem(element, itemQuantity);

  let data = sessionStorage.getItem(element);
  cartcount();
}
function addtocart4() {
  const element = document.getElementById("4").value;

  var my = sessionStorage.getItem(element);
  var itemQuantity = Number(my);
  console.log(itemQuantity);
  if (element == null) {
    itemQuantity = 0;
  } else {
    itemQuantity += 1;
  }

  alert("ORDER PLACED FOR : " + element + "\n" + "QUANTITY : " + itemQuantity);

  sessionStorage.setItem(element, itemQuantity);

  let data = sessionStorage.getItem(element);
  cartcount();
}
function addtocart5() {
  const element = document.getElementById("5").value;

  var my = sessionStorage.getItem(element);
  var itemQuantity = Number(my);
  console.log(itemQuantity);
  if (element == null) {
    itemQuantity = 0;
  } else {
    itemQuantity += 1;
  }

  alert("ORDER PLACED FOR : " + element + "\n" + "QUANTITY : " + itemQuantity);

  sessionStorage.setItem(element, itemQuantity);

  let data = sessionStorage.getItem(element);
  cartcount();
}
function addtocart6() {
  const element = document.getElementById("6").value;

  var my = sessionStorage.getItem(element);
  var itemQuantity = Number(my);
  console.log(itemQuantity);
  if (element == null) {
    itemQuantity = 0;
  } else {
    itemQuantity += 1;
  }

  alert("ORDER PLACED FOR : " + element + "\n" + "QUANTITY : " + itemQuantity);

  sessionStorage.setItem(element, itemQuantity);

  let data = sessionStorage.getItem(element);
  cartcount();
}

function cartcount() {
  var m = 0;
  for (var i = 0; i < sessionStorage.length; i++) {
    var key = sessionStorage.key(i);
    var value = sessionStorage.getItem(key);
    value = Number(value);
    m += value;
  }
  document.getElementById("cartCircle").innerText = m;
}

window.onload = cartcount;
